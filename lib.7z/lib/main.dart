import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:walidgpt/about.dart';
import 'package:walidgpt/history.dart';
import 'package:walidgpt/login.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:walidgpt/models/message.dart';
import 'package:walidgpt/globals.dart';
import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:walidgpt/settings.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'WalidGPT',
      theme: ThemeData(
        colorScheme: ColorScheme.light(),
        useMaterial3: true,
      ),
      home: const Login(),
    );
  }
}

class MessagePage extends StatefulWidget {
  int? session;
  MessagePage({super.key,this.session});
  @override
  State<MessagePage> createState() => _MessagePageState(session);
}

class _MessagePageState extends State<MessagePage> {
  int? session;
  SpeechToText _speechToText = SpeechToText();
  bool _speechEnabled = false;
  String _lastWords = '';
  final TextEditingController _controller = TextEditingController();
  List<Message> messages = [];

  _MessagePageState(this.session);
  @override
  void initState() {
    fetchMessages();
    initSession();
    super.initState();
    _initSpeech();
  }

  void initSession() async{
    session ??= await createSession() ;
    print(session);
  }
  void fetchMessages() async {
    var url = Uri.parse('http://${server}:8000/messengers/list_messages/${session}/');
    final response = await get(
      url,
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Token ${token}'
      },
    );
    print(response.body);
    List<dynamic> data = json.decode(response.body);
    setState(() {
      for (Map<String, dynamic> message in data) {
        messages.add(Message.fromJson(message));
      }
    });
  }

  /// This has to happen only once per app
  void _initSpeech() async {
    _speechEnabled = await _speechToText.initialize();
    setState(() {});
  }

  /// Each time to start a speech recognition session
  void _startListening() async {
    await _speechToText.listen(onResult: _onSpeechResult);
    setState(() {});
  }

  /// Manually stop the active speech recognition session
  /// Note that there are also timeouts that each platform enforces
  /// and the SpeechToText plugin supports setting timeouts on the
  /// listen method.
  void _stopListening() async {
    await _speechToText.stop();
    setState(() {});
  }

  /// This is the callback that the SpeechToText plugin calls when
  /// the platform returns recognized words.
  void _onSpeechResult(SpeechRecognitionResult result) {
    setState(() {
      _lastWords = result.recognizedWords;
      _controller.text = _lastWords;
    });
  }

  Future<Message> createMessage() async {
    var url = Uri.parse('http://${server}:8000/messengers/create_messages/');
    final response = await post(url,
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
          'Authorization': 'Token ${token}'
        },
        body: json.encode({
          'session': session,
          'sender': myProfile.id,
          'content': _controller.text.trim(),
        }));
    _controller.text = '';

    Map data = json.decode(response.body);
    Message message = Message.fromJson(data);
    return message;
  }

  Future<int?> createSession() async {
    var url = Uri.parse('http://${server}:8000/messengers/sessions/');
    final response = await post(url,
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
          'Authorization': 'Token ${token}'
        },
        body: json.encode({
        }));
    _controller.text = '';

    Map data = json.decode(response.body);
    int id = data['id'];
    return id;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        surfaceTintColor: Colors.white,
        backgroundColor: Colors.white,
        title: AnimatedTextKit(
          totalRepeatCount: 1,
          animatedTexts: [
            TypewriterAnimatedText(
              'Hello Hello Hello',
              speed: const Duration(milliseconds: 100), 
            ),
          ],
        ),
        actions: [
          IconButton(onPressed: () async {
            session = await createSession();
            setState(() {
               messages = [];
            });
          }, icon: Icon(Icons.add)),
          IconButton(onPressed: () {}, icon: Icon(Icons.more_vert))
        ],
      ),
      drawer: Drawer(
      width: MediaQuery.of(context).size.width * 0.9,
      child: ListView(
        // Remove padding
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            accountName: Text(
              '${myProfile.firstName} ${myProfile.lastName}',
              style: TextStyle(color: Colors.black),
            ),
            accountEmail: Text(
              '${myProfile.email}',
              style: TextStyle(color: Colors.black),
            ),
            currentAccountPicture: CircleAvatar(
              backgroundColor: Colors.lightGreen,
              child:
                  ClipOval(child: Text('${myProfile.firstName![0]}${myProfile.lastName![0]}'.toUpperCase(), style: TextStyle(fontSize: 20))),
            ),
            decoration: BoxDecoration(
              image: DecorationImage(
                  fit: BoxFit.fill,
                  image: AssetImage('assets/images/profile_background.jpg')),
            ),
          ),
          ListTile(
            leading: Icon(
              Icons.add,
              color: Colors.black54,
            ),
            title: Text(
              'New Chat',
              style: TextStyle(color: Colors.black54),
            ),
            onTap: ()async {
              session = await createSession();
            setState(() {
               messages = [];
            });
            Navigator.of(context).pop();
            },
          ),
          ListTile(
            leading: Icon(
              Icons.history,
              color: Colors.black54,
            ),
            title: Text(
              'History',
              style: TextStyle(color: Colors.black54),
            ),
            onTap: () {
              Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: ((context) =>
                                    HistroyPage())));
            },
          ),
          ListTile(
            leading: Icon(
              Icons.info,
              color: Colors.black54,
            ),
            title: Text(
              'About',
              style: TextStyle(color: Colors.black54),
            ),
            onTap: () async {
              Navigator.of(context).pop();
              showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return showAbout(context);
                  });
            },
          ),
          Divider(color: Colors.black54, indent: 40, endIndent: 40),
          ListTile(
            leading: Icon(
              Icons.settings,
              color: Colors.black54,
            ),
            title: Text(
              'Settings',
              style: TextStyle(color: Colors.black54),
            ),
            onTap: () {
              Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: ((context) =>
                                    SettingsPage())));
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.support_agent,
              color: Colors.black54,
            ),
            title: const Text(
              'Contact Us',
              style: TextStyle(color: Colors.black54),
            ),
            onTap: () {},
          ),
        ],
      ),
    ),
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Container(
                padding: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
                child: SingleChildScrollView(
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                            height: MediaQuery.of(context).size.height - 200,
                            child: buildMessages(messages))
                      ]),
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  height: 100,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: 100,
                        width: MediaQuery.of(context).size.width * 0.85,
                        padding:
                            EdgeInsets.symmetric(vertical: 20, horizontal: 15),
                        child: TextField(
                          controller: _controller,
                          decoration: InputDecoration(
                            hintText: 'Message',
                            filled: true,
                            fillColor: Colors.blue.shade50,
                            labelStyle: TextStyle(fontSize: 12),
                            contentPadding: EdgeInsets.all(20),
                            enabledBorder: OutlineInputBorder(
                                borderSide:
                                    BorderSide(color: Colors.blue.shade50),
                                borderRadius: BorderRadius.circular(50)),
                            focusedBorder: OutlineInputBorder(
                                borderSide:
                                    BorderSide(color: Colors.blue.shade50),
                                borderRadius: BorderRadius.circular(50)),
                            prefixIcon: IconButton(
                              icon: Icon(_speechToText.isNotListening
                                  ? Icons.mic_off
                                  : Icons.mic),
                              onPressed: _speechToText.isNotListening
                                  ? _startListening
                                  : _stopListening,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        height: 40,
                        width: 40,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(50),
                            color: Colors.black12),
                        child: IconButton(
                          icon: Icon(
                            Icons.arrow_upward,
                            color: Colors.black45,
                          ),
                          onPressed: () async {
                            setState(
                              () {
                                messages.add(Message(
                                    sender: 'patient',
                                    content: _controller.text.trim()));
                              },
                            );
                            Message message = await createMessage();
                            setState(
                              () {
                                messages.add(message);
                              },
                            );
                          },
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildMessages(List<Message> messages) => ListView.builder(
        itemCount: messages.length,
        itemBuilder: (context, index) {
          final message = messages[index];
          return Container(
            margin: EdgeInsets.fromLTRB(0, 0, 0, 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                message.sender == 'patient'
                    ? CircleAvatar(
                        backgroundColor: Colors.lightGreen,
                        radius: 13,
                        child: Text(
                          'WR',
                          style: TextStyle(fontSize: 10),
                        ),
                      )
                    : CircleAvatar(
                        backgroundColor: Colors.lightGreen,
                        radius: 13,
                        child: ClipOval(
                            child: Image.asset('assets/images/logo.jpg')),
                      ),
                SizedBox(
                  width: 10,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 4,
                    ),
                    Text(
                      (message.sender == 'patient' ? 'Walid Tolba' : 'Chat Bot')
                          .toUpperCase(),
                      style: TextStyle(fontSize: 12),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.8,
                      child: Text(
                        message.content!,
                        style: TextStyle(fontSize: 16),
                      ),
                    )
                  ],
                )
              ],
            ),
          );
        },
      );
}
