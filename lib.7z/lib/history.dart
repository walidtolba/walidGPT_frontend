import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:walidgpt/models/session.dart';
import '../globals.dart';

class HistroyPage extends StatefulWidget {
  HistroyPage({super.key});

  @override
  State<HistroyPage> createState() => _HistroyPageState();
}

class _HistroyPageState extends State<HistroyPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title:
            Text('Sessions', style: TextStyle(letterSpacing: 3)),
        actions: [
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.notifications_none_sharp),
          ),
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.chat),
          ),
        ],
      ),
      body: Sessions(),
    );
  }
}

class Sessions extends StatelessWidget {
  const Sessions({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: ListSessions(),
    );
  }
}

class ListSessions extends StatefulWidget {
  const ListSessions({super.key});

  @override
  State<ListSessions> createState() => _ListSessionsState();
}

class _ListSessionsState extends State<ListSessions> {
  List<Session> sessions = [];

  @override
  void initState() {
    fetchSessions();
    super.initState();
  }

  void fetchSessions() async {
    var url = Uri.parse('http://${server}:8000/messengers/sessions/');
    final response = await get(
      url,
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Token ${token}'
      },
    );
    print(response.body);
    List<dynamic> data = json.decode(response.body);
    print(data);
    setState(() {
      for (Map<String, dynamic> session in data) {
        sessions.add(Session.fromJson(session));
      }
    });
    print('herererer');
  }

  @override
  Widget build(BuildContext context) {
    return buildMySessions(sessions);
  }

  Widget buildMySessions(List<Session> sessions) => ListView.builder(
        itemCount: sessions.length,
        itemBuilder: (context, index) {
          final record = sessions[index];
          return InkWell(
              child: Container(
                margin: EdgeInsets.symmetric(vertical: 4),
                padding: EdgeInsets.all(6),
                width: double.infinity,
                height: 65,
                decoration: BoxDecoration(
                  border: Border.all(color: Color.fromARGB(255, 200, 200, 200)),
                  borderRadius: BorderRadius.circular(10),
                  color: Color.fromARGB(255, 250, 250, 250),
                  // image: DecorationImage(
                  //    image: AssetImage('assets/images/background.jpg'))
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        SizedBox(width: 8),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${record.title}',
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              height: 4,
                            ),
                            Text(
                              '${record.creationDate!.year}-${record.creationDate!.month}-${record.creationDate!.day}',
                              style: TextStyle(color: Colors.black54),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        InkWell(
                          child: Icon(Icons.track_changes, color: Colors.red),
                          onTap: () async {
                            var url = Uri.parse(
                                'http://${server}:8000/messengers/my_records/');
                            final response = await delete(url,
                                headers: {
                                  'Content-Type':
                                      'application/json; charset=UTF-8',
                                  'Authorization': 'Token ${token}'
                                },
                                body: jsonEncode({
                                  "id": record.id,
                                }));
                            print(response.body);
                            if (response.statusCode == 200) {
                              setState(() {
                                sessions.remove(record);
                              });
                            }
                          },
                        ),
                        SizedBox(width: 6)
                      ],
                    ),
                  ],
                ),
              ),
              onTap: () {
            
              });
        },
      );
}