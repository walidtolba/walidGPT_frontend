import 'package:flutter/material.dart';
import 'package:walidgpt/models/user.dart';

var server = '192.168.53.166';
var token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6IndhbGlkLnRvbGJhQGdtYWlsLmNvbSIsImlhdCI6MTcwNDczMDgxMiwibmJmIjoxNzA0NzMwNTEyLCJleHAiOjE3MDUxNjI4MTJ9.-zREzdWnYAIXRggYDVXD_0I4sl-8azpk5p35zTn9cHk';
var myProfile = User();
Widget errorMessage(BuildContext context, String message) {
  return Dialog(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
    child: Container(
        height: 150,
        padding: EdgeInsets.fromLTRB(32, 16, 32, 16),
        child: Column(
          children: [
            Text(
              'ERROR',
              style: TextStyle(letterSpacing: 2, fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 30,
            ),
            Text(message),
          ],
        )),
  );
}